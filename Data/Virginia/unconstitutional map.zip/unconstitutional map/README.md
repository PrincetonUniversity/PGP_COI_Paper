This folder contains the shapefile for the full enacted House of Delegates map. Below is the enacted map, limited to the 33 districts affected by the Bethune-Hill case.

[![Enacted map](enacted_preview.png)](https://rawgit.com/PrincetonUniversity/VA-gerrymander/master/Maps/Interactive/map_comparison.html)
<p align="center">Click to explore the map interactively.</p>
